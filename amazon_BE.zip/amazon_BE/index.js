const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');


app.use(express.json());
app.use(express.urlencoded({extended : true}));
app.use(express.static(path.join(__dirname, '/public')));
app.set('view engin','ejs')


app.get('/', function(req, res){
    res.render("index.ejs")
})


app.get('/login', function(req, res){
    res.render("login.ejs")
})


app.get('/signup', function(req, res){
    res.render("signup.ejs")
})

app.get('/login2', function(req, res){
    res.render("login2.ejs")
})


app.get('/cart', function(req, res){
    res.render("cart.ejs")
})

app.get('/order', function(req, res){
    res.render("order.ejs")
})

app.get('/index1', function(req, res){
    res.render("index1.ejs")
})


app.get('/product', function(req, res){
    res.render("product.ejs")
})


app.get('/product2', function(req, res){
    res.render("product2.ejs")
})

app.get('/pyment', function(req, res){
    res.render("pyment.ejs")
})




// app.get('/login/:filename', function(req , res, ){
//     res.render('login.ejs',{filename:req.params.filename});
// })



app.listen(3000);